<?php
require( 'core/config.php' );
require( 'core/app.php' );
require('core/controller.php');
require ('core/model.php');
new app;
?>
