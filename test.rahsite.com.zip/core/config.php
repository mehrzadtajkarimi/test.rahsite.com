<?php

define('URL','http://localhost/test.rahsite.com/');
