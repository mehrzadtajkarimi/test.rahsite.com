<p class="card-body text-center font-face2 font-sizs-20">((در حال ساخت میباشد))</p>
<img class="img-fluid d-block m-auto w-50" src="public/image/test-product.jpg" alt="test-product.jpg">
