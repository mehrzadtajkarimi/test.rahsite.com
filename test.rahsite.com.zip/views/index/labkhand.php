<section id="labkhand" class="wow fadeIn shadow" data-wow-offset="300" data-wow-duration="2s">
    <div class="container">
        <div class="row">
            <div class="offset-5"></div>
            <div class="col-md-7">
                <div class="card border-0 bg-transparent">
                    <div class="card-body mt-md-5">
                        <div class="card-header border-0 bg-transparent"><h5 class="text-light"> لبخند مشتریان</h5>
                        </div>
                        <div class="card-text mt-md-2"><p class="text-white text-justify">طرح لبخند مشتریان با هدف
                                نمایش رضایتمندی مشتریان
                                در قالب کلیپ به تصویر نمایش درآمده است.
                                این طرح همچنان ادامه خواهد داشت...</p></div>
                        <div class="card-footer  border-0 bg-transparent">
                            <button type="button" class="btn btn-outline-light btn-sm float-left mt-md-5 mb-md-5">
                                ورود به لبخند مشتریان
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
