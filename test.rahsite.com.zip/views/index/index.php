<base href="<?= URL ?>">
<main>

    <?php require ('banner-big-bg.php')?>
    <?php require ('why.php')?>
    <?php require ('center-features.php')?>
    <?php require ('khadamat.php')?>
    <?php require ('labkhand.php')?>
    <?php require ('amkanat.php')?>
    <?php require ('nemonekar.php')?>
    <?php require ('darkhast.php')?>

</main>
