<section id="amkanat">
    <div class="container-fluid">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="card border-0 bg-transparent mt-5 mb-5">
                        <div class="card-header border-0 bg-transparent ">
                            <h5 class="text-center"> هر آنچه برای راه اندازی کسب و کار اینترنتی تا رسیدن به موفقیت
                                نیاز خواهید داشت.</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-3 col-md-6 d-flex justify-content-center p-3">
                                    <i class="fas  fa-fingerprint fa-2x  text-muted align-self-center"></i>
                                    <span class="align-self-center font-small mr-3">تضمین ۱۰۰% بازگشت وجه</span>
                                </div>
                                <div class="col-lg-3 col-md-6 d-flex justify-content-center p-3">
                                    <i class="fas fa-mobile-alt fa-2x  text-muted align-self-center"></i>
                                    <span class="align-self-center font-small mr-3">پنل ارسال پیامک رایگان</span>
                                </div>
                                <div class="col-lg-3 col-md-6 d-flex justify-content-center p-3">
                                    <i class="fas fa-user-cog fa-2x  text-muted align-self-center"></i>
                                    <span class="align-self-center font-small mr-3">پشتیبانی ۲۴/۷ همیشگی</span>
                                </div>
                                <div class="col-lg-3 col-md-6 d-flex justify-content-center p-3">
                                    <i class="fas fa-graduation-cap fa-2x  text-muted align-self-center"></i>
                                    <span class="align-self-center font-small mr-3">آموزش مدیریت سایت</span>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
