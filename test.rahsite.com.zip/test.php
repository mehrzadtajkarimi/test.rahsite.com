<?php
$data =time();
echo $data;